#include "PreCompile.h"
#include "GameEngineDebugRenderData.h"

GameEngineDebugRenderData::GameEngineDebugRenderData()
{
}

GameEngineDebugRenderData::~GameEngineDebugRenderData()
{
}

