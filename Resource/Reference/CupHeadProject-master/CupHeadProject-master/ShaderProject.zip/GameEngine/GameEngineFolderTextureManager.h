#pragma once
#include "GameEngineDevice.h"
#include <mutex>

// ���� : 
class GameEngineFolderTexture;
class GameEngineLevel;
class GameEngineFolderTextureManager
{
private:
	static GameEngineFolderTextureManager* Inst;
	static std::mutex ManagerLock;

public:
	static GameEngineFolderTextureManager& GetInst()
	{
		return *Inst;
	}

	static void Destroy()
	{
		if (nullptr != Inst)
		{
			delete Inst;
			Inst = nullptr;
		}
	}

private:	// member Var
	std::map<std::string, GameEngineFolderTexture*> ResourcesMap;

	std::map<GameEngineLevel*, std::map<std::string, GameEngineFolderTexture*>> GlobalResourcesMap;

public:
	GameEngineFolderTexture* Load(const std::string& _Path);

	// �̸� ���� ����
	GameEngineFolderTexture* Load(const std::string& _Name, const std::string& _Path);
	// ��Ͽ��� ã�´�.
	GameEngineFolderTexture* Find(const std::string& _Name);

	GameEngineFolderTexture* LoadLevelRes(const std::string& _Path);
	GameEngineFolderTexture* LoadLevelRes(const std::string& _Name, const std::string& _Path);
	GameEngineFolderTexture* FindLevelRes(const std::string& _Name);
	void DestroyLevelRes(GameEngineLevel* _Level);

private:
	GameEngineFolderTextureManager(); // default constructer ����Ʈ ������
	~GameEngineFolderTextureManager(); // default destructer ����Ʈ �Ҹ���

protected:		// delete constructer
	GameEngineFolderTextureManager(const GameEngineFolderTextureManager& _other) = delete; // default Copy constructer ����Ʈ ���������
	GameEngineFolderTextureManager(GameEngineFolderTextureManager&& _other) noexcept; // default RValue Copy constructer ����Ʈ RValue ���������

private:		//delete operator
	GameEngineFolderTextureManager& operator=(const GameEngineFolderTextureManager& _other) = delete; // default Copy operator ����Ʈ ���� ������
	GameEngineFolderTextureManager& operator=(const GameEngineFolderTextureManager&& _other) = delete; // default RValue Copy operator ����Ʈ RValue ���Կ�����
};




