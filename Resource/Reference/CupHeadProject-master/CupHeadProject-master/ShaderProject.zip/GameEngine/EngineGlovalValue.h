#pragma once

#define GV_GAMEFILENAME "CupHeadProject"
