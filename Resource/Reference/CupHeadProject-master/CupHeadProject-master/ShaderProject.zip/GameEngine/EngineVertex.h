#pragma once
#include <GameEngineBase/GameEngineMath.h>


struct GameEngineVertex
{
public:
	float4 Postion;
	float4 Texcoord;
	float4 Color;
};