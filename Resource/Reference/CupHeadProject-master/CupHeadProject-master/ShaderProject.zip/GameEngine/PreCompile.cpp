#include "PreCompile.h"

#pragma comment (lib, "GameEngineBase.lib")
