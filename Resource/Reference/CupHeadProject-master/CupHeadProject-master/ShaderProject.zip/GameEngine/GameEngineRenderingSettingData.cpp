#include "PreCompile.h"
#include "GameEngineRenderingSettingData.h"

