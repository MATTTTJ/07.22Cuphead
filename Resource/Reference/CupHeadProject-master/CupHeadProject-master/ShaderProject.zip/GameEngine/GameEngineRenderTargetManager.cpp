#include "PreCompile.h"
#include "GameEngineRenderTargetManager.h"
#include "GameEngineRenderTarget.h"

GameEngineRenderTargetManager* GameEngineRenderTargetManager::Inst = new GameEngineRenderTargetManager();

GameEngineRenderTargetManager::GameEngineRenderTargetManager() // default constructer ����Ʈ ������
{

}

GameEngineRenderTargetManager::~GameEngineRenderTargetManager() // default destructer ����Ʈ �Ҹ���
{
	for (const std::pair<std::string, GameEngineRenderTarget*>& Res : ResourcesMap)
	{
		if (nullptr != Res.second)
		{
			delete Res.second;
		}
	}

	ResourcesMap.clear();
}

GameEngineRenderTargetManager::GameEngineRenderTargetManager(GameEngineRenderTargetManager&& _other) noexcept  // default RValue Copy constructer ����Ʈ RValue ���������
{

}



GameEngineRenderTarget* GameEngineRenderTargetManager::Create(const std::string& _Name, const std::string& _TextureName, float4 _Color)
{
	GameEngineRenderTarget* FindRes = Find(_Name);
#ifdef _DEBUG
	if (nullptr != FindRes)
	{
		GameEngineDebug::MsgBoxError(_Name + " Is Overlap Create");
	}
#endif // _DEBUG


	GameEngineRenderTarget* NewRes = new GameEngineRenderTarget();
	NewRes->SetName(_Name);
	NewRes->Create(_TextureName, _Color);

	// �׸��� ���Ұų�?

	ResourcesMap.insert(std::map<std::string, GameEngineRenderTarget*>::value_type(_Name, NewRes));
	return NewRes;
}

GameEngineRenderTarget* GameEngineRenderTargetManager::Load(const std::string& _Path)
{
	return Load(GameEnginePath::GetFileName(_Path), _Path);
}

GameEngineRenderTarget* GameEngineRenderTargetManager::Load(const std::string& _Name, const std::string& _Path)
{
	GameEngineRenderTarget* FindRes = Find(_Name);
#ifdef _DEBUG
	if (nullptr != FindRes)
	{
		GameEngineDebug::MsgBoxError(_Name + " Is Overlap Load");
	}
#endif // _DEBUG

	GameEngineRenderTarget* NewRes = new GameEngineRenderTarget();
	NewRes->SetName(_Name);


	ResourcesMap.insert(std::map<std::string, GameEngineRenderTarget*>::value_type(_Name, NewRes));
	return NewRes;
}

GameEngineRenderTarget* GameEngineRenderTargetManager::Find(const std::string& _Name)
{
	std::map<std::string, GameEngineRenderTarget*>::iterator FindIter = ResourcesMap.find(_Name);

	if (FindIter != ResourcesMap.end())
	{
		return FindIter->second;
	}

	return nullptr;
}