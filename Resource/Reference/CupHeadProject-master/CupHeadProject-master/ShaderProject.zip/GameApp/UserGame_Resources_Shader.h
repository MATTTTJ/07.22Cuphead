#pragma once

void AppShaderLoad();
