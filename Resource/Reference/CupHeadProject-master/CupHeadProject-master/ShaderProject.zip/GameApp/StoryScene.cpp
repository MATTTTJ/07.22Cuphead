#include "PreCompile.h"
#include "StoryScene.h"

StoryScene::StoryScene() // default constructer ����Ʈ ������
{

}

StoryScene::~StoryScene() // default destructer ����Ʈ �Ҹ���
{

}

void StoryScene::LevelStart()
{
}

void StoryScene::LevelUpdate(float _DeltaTime)
{
}

void StoryScene::LevelChangeEndEvent(GameEngineLevel* _NextLevel)
{
}

void StoryScene::LevelChangeStartEvent(GameEngineLevel* _NextLevel)
{
}
