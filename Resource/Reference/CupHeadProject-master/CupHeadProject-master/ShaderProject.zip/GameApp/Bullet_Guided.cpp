#include "PreCompile.h"
#include "Bullet.h"

Bullet_Guided::Bullet_Guided() :
	Target_(nullptr),
	OriginDir_(),
	TargetDir_(),
	OriginSpeed_(0.f),
	TargetSpeed_(0.f)
{
}

Bullet_Guided::~Bullet_Guided()
{
}

void Bullet_Guided::Start()
{

}

void Bullet_Guided::Update(float _DeltaTime)
{
}