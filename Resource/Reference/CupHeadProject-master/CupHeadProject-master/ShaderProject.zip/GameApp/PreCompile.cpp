#include "PreCompile.h"

#pragma comment (lib, "GameEngineBase.lib")
#pragma comment (lib, "GameEngine.lib")