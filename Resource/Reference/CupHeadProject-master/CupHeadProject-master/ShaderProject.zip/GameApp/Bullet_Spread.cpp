#include "PreCompile.h"
#include <GameEngine/GameEngineImageRenderer.h>
#include "Bullet.h"

Bullet_Spread::Bullet_Spread()
{
}

Bullet_Spread::~Bullet_Spread()
{
}

void Bullet_Spread::Start()
{
	Bullet::Start();
}

void Bullet_Spread::Update(float _DeltaTime)
{
}

void Bullet_Spread::BulletDeath()
{
}