#pragma once
#include "SceneBase.h"
#include <GameEngineBase/GameEngineFSM.h>

// ���� :
class TitleScene : public SceneBase
{
public:
	// constrcuter destructer
	TitleScene();
	~TitleScene();

	// delete Function
	TitleScene(const TitleScene& _Other) = delete;
	TitleScene(TitleScene&& _Other) noexcept = delete;
	TitleScene& operator=(const TitleScene& _Other) = delete;
	TitleScene& operator=(TitleScene&& _Other) = delete;

protected:
	void LevelStart() override;
	void LevelUpdate(float _DeltaTime) override;
	void LevelChangeEndEvent(GameEngineLevel* _NextLevel) override;
	void LevelChangeStartEvent(GameEngineLevel* _PrevLevel) override;
private:
	GameEngineFSM<TitleScene> LoadState_;

	class GameEngineImageRenderer* FontImageRenderer;

	void Init_Update(float _DeltaTime);

	void ResourcesLoad_Start();
	void ResourcesLoad_Update(float _DeltaTime);
	void ResourcesLoad_End();

	void LevelLoop_Start();
	void LevelLoop_Update(float _DeltaTime);
	void LevelLoop_End();

private:
	bool TobeNext_;
	bool end_;

	bool SceneStart_;
	float timecheck_;
};

