#pragma once

enum class CollisonType
{
	None,
	Effect,
	Player,
	UI,
	Monster,
	Bullet,
};

