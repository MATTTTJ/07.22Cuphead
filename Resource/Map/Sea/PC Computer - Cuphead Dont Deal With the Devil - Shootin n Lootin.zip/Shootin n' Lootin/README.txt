Shootin n' Lootin from Cuphead ripped by DogToon64.

If used, give credit to Studio MDHR.

Credit to DogToon64 is optional, but would be nice.