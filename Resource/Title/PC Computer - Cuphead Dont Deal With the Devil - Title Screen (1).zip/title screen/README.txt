Title Screen from Cuphead ripped by DogToon64.
DLC Title Screen ripped by Fuley-la-joo.

If used, give credit to Studio MDHR.

Credit to DogToon64 is optional, but would be nice.